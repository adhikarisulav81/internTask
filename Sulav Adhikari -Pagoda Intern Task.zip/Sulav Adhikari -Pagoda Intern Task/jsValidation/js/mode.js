//js for mode functionality//
function myFunction() {
    var element = document.body;
    element.classList.toggle("change-mode");
 }

//form data validation using JS
 function validateData() {

    var pattern = /^[A-Za-z0-9]+$/; //regular expression (regex) pattern
    var a = document.getElementById('uname').value;

    //checking empty username textfield.
    if(a==""){
        alert("Username is required..");
        myForm.uname.focus();
        return false;
    }

    if(a.length<3){
        alert("Username must be more than 3 character..");
        myForm.uname.focus();
        return false;
    }

    if(a.length>20){
        alert("Username must be less than 20 character..");
        myForm.uname.focus();
        return false;
    }

    //checking the validation of regex data
    if(a.match(pattern)){
        true;
    }else{
        alert("Enter Valid Username..");
        myForm.uname.focus();
        return false;
    }

    if(myForm.password.value==""){
        alert("Password is required..");
        myForm.password.focus();
        return false;
    }

    if(myForm.cpassword.value==""){
        alert("Confirm Password is required..");
        myForm.cpassword.focus();
        return false;
    }

    //checking the match of the password and confirm password textfields
    if(myForm.password.value != myForm.cpassword.value){
        alert("Please match your password.");
        myForm.password.focus();
        return false;
    }
    
    alert("Form Submitted Successfully.");
}

//show and hide functionality in the password section using eye icon
function checkFunction(){
    var x = document.getElementById("cpassword");
    var y = document.getElementById("hide1");
    var z = document.getElementById("hide2");

    if(x.type === 'password'){
        x.type = "text";
        y.style.display = "block";
        z.style.display = "none";
    }else{
        x.type = "password";
        y.style.display = "none";
        z.style.display = "block";
    }
}

function passFunction(){
    var x = document.getElementById("password");
    var y = document.getElementById("hide3");
    var z = document.getElementById("hide4");

    if(x.type === 'password'){
        x.type = "text";
        y.style.display = "block";
        z.style.display = "none";
    }else{
        x.type = "password";
        y.style.display = "none";
        z.style.display = "block";
    }
}